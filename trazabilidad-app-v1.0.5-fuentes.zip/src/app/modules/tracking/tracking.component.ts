import {Component} from '@angular/core';

@Component({
    templateUrl: './tracking.template.html',
    styleUrls: ['./tracking.scss', './tracking.mobile.scss']
})
export class TrackingComponent {

}
