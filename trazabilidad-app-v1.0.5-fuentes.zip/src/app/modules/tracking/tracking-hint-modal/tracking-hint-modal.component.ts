import {Component} from '@angular/core';

@Component({
    templateUrl: './tracking-hint-modal.template.html',
    styleUrls: ['./tracking-hint-modal.scss', './tracking-hint-modal.mobile.scss']
})

export class TrackingHintModalComponent {



}
