import {Component} from '@angular/core';

@Component({
    templateUrl: './tracking-not-found.template.html',
    styleUrls: ['./tracking-not-found.scss']
})
export class TrackingNotFoundComponent {

}
